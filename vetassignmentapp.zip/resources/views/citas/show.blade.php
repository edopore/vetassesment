@extends('app')
@section('content')
Hola
@endsection