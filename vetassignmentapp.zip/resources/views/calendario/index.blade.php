@extends('app')
@section('content')
    
    <div class="container ">
        <div id='calendar'>
        </div>
    </div>
@endsection
