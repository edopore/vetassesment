
<?php $__env->startSection('content'); ?>
<div class="container w-100 border p-12 my-12">
        <?php if(session('success')): ?>
            <h5 class="alert alert-success"><?php echo e(session('success')); ?></h5>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <h5 class="alert alert-danger"><?php echo e(session('error')); ?></h5>
        <?php endif; ?>
        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h5 class="alert alert-danger"><?php echo e($message); ?></h5>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <form action="<?php echo e(route('citas.index')); ?>" method="GET">
            <div>
                <div>
                    <label for="date">Fecha</label>
                    <input type="date" name="fecha" id="date">  
                    <button class="btn btn-success">Buscar</button>
                </div>
            </div>
        </form>
        <?php if($count>0): ?>
        <table class="table text-align-center">
            <tr>
                <td>Identificación</td>
                <td>Nombre del Propietario</td>
                <td>Nombre de la Mascota</td>
                <td>Fecha de la Cita</td>
                <td>Hora de la cita</td>
                <td>Acción</td>
            </tr>
            <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cita->identification); ?></td   >
                <td><?php echo e($cita->ownerFullName); ?></td    >
                <td><?php echo e($cita->petName); ?></td  >
                <td><?php echo e($cita->date); ?></td >
                <td><?php echo e($cita->time); ?></td >
                <td>
                <form action="<?php echo e(route('citas.destroy',['cita'=>$cita->id])); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <a class="btn btn-primary" href="<?php echo e(route('citas.edit',['cita'=>$cita->id])); ?>">Editar</a>
                    <button class="btn btn-danger">Eliminar</button>
                </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <h1 class="alert alert-danger">No hay Información</h1>
            <?php endif; ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vetassignmentapp\resources\views/citas/index.blade.php ENDPATH**/ ?>