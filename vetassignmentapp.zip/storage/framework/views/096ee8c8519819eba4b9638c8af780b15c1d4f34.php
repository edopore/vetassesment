
<?php $__env->startSection('content'); ?>
    <div class="container w-25 border p-4 my-4">
        <form action="<?php echo e(route('citas.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="identification">Identificación</label>
                <input type="text" class="form-control" name="identification" id="identification" > 
            </div>
            <div class="form-group">
                <label for="ownerName">Nombre Completo del dueño</label>
                <input type="text" class="form-control" name="ownerFullName" id="ownerFullName" > 
            </div>
            <div class="form-group">
                <label for="petName">Nombre de la Mascota</label>
                <input type="text" class="form-control" name="petName" id="petName" > 
            </div>
            <div class="form-group">
            <div>
                <label for="date">Fecha de la Cita</label>
                <input type="date" class="form-control" name="date" id="date">
                <label for="time">Hora de la cita</label>
                <input type="time" min="14:00" max="18:00" step="3600" value="14:00" class="form-control" name="time" id="time"> 
            </div>
            </div>
            <button type="submit" class="btn btn-primary">Asignar Cita</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vetassignmentapp\resources\views/citas/create.blade.php ENDPATH**/ ?>