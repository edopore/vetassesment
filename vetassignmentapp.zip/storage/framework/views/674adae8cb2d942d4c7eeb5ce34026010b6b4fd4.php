

<?php $__env->startSection('content'); ?>
<div class="container w-25 border p-4 my-4">
        <form action="<?php echo e(route('citas.update',['cita'=>$cita->id])); ?>" method="post">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <?php if(session('success')): ?>
            <h5 class="alert alert-success"><?php echo e(session('success')); ?></h5>
            <?php endif; ?>
            <?php $__errorArgs = ['error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h5 class="alert alert-danger"><?php echo e($message); ?></h5>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-group">
                <label for="identification">Identificación</label>
                <input type="text" class="form-control" name="identification" id="identification" value="<?php echo e($cita->identification); ?>" disabled> 
            </div>
            <div class="form-group">
                <label for="ownerName">Nombre Completo del dueño</label>
                <input type="text" class="form-control" name="ownerFullName" id="ownerFullName" value="<?php echo e($cita->ownerFullName); ?>" disabled> 
            </div>
            <div class="form-group">
                <label for="petName">Nombre de la Mascota</label>
                <input type="text" class="form-control" name="petName" id="petName" value="<?php echo e($cita->petName); ?>" disabled> 
            </div>
            <div class="form-group">
            <div>
                <label for="date">Fecha de la Cita</label>
                <input type="date" class="form-control" name="date" id="date" value="<?php echo e($cita->date); ?>">
                <label for="time">Hora de la cita</label>
                <input type="time" class="form-control" name="time" id="time" value="<?php echo e($cita->time); ?>"> 
            </div>
            </div>
            <button type="submit" class="btn btn-primary">Reasignar Cita</button>
            <a class="btn btn-danger" href="<?php echo e(route('citas.index')); ?>">Volver</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vetassignmentapp\resources\views/citas/edit.blade.php ENDPATH**/ ?>