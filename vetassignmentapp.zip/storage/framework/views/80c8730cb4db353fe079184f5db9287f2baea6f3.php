
<?php $__env->startSection('content'); ?>
Hola
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vetassignmentapp\resources\views/citas/show.blade.php ENDPATH**/ ?>