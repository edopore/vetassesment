
<?php $__env->startSection('content'); ?>
    
    <div class="container ">
        <div id='calendar'>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vetassignmentapp\resources\views/calendario/index.blade.php ENDPATH**/ ?>